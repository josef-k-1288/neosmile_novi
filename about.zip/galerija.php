<?php include 'header.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>

    <!-- font awesome cdn link  -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> -->

    <!-- bootstrap cdn link  -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css"> -->

    <!-- custom css file link  -->
    <!-- <link rel="stylesheet" href="css/style.css"> -->

</head>

<body>




    <div class="container_galerija">

        <!-- <h1>image gallery</h1> -->

        <div class="image-container">

            <div class="image"><img src="images/stolica.jpg" alt="" id="prva-slika"></div>
            <div class="image"><img src="images/about-img.jpg" alt="" id="druga-slika"></div>
            <div class="image"><img src="images/home-bg.jpg" alt="" id="treca-slika"></div>
            <div class="image"><img src="images/tim/Ljiska_test.jpg" alt="" id="cetvrta-slika"></div>
            <div class="image"><img src="images/stolica.jpg" alt="" id="peta-slika"></div>
            <div class="image"><img src="images/stolica.jpg" alt="" id="sesta-slika"></div>
        </div>


        <div class="popup-image">
            <span>&times;</span>
            <img src="Wordpress.jpg" alt="">

            <i class="fas fa-arrow-left leva-ikonica" onclick="back()"></i>
            <i class="fas fa-arrow-right desna-ikonica" onclick="next()"></i>

        </div>

    </div>


    <script>
        document.querySelectorAll('.image-container img').forEach(image => {
            image.onclick = () => {
                document.querySelector('.popup-image').style.display = 'block';
                document.querySelector('.header').style.display = 'none';
                document.querySelector('.popup-image img').src = image.getAttribute('src');

            }
        });

        document.querySelector('.popup-image span').onclick = () => {
            document.querySelector('.popup-image').style.display = 'none';
            document.querySelector('.header').style.display = 'block';
        }
    </script>

    





    <?php include 'footer.php' ?>


</body>

</html>