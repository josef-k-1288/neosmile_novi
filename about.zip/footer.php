<section class="footer">
        <div class="box-container container">
            <div class="box">
                <i class="fas fa-phone"></i>
                <h3>phone number</h3>
                <p>+381 69 2717 777</p>
                <!-- <p>+111-222-333</p> -->
            </div>

            <div class="box">
                <i class="fas fa-map-marker-alt"></i>
                <h3>our address</h3>
                <p>Vrtlarska 7b, 11 080, Zemun</p>
            </div>

            <div class="box">
                <i class="fas fa-map-marker-alt"></i>
                <h3>opening hours</h3>
                <p>Ponedeljak-petak: 11:00 – 19:00</p>
                <p>Vikendom: 11:00 – 17:00</p>
            </div>

            <div class="box">
                <i class="fas fa-envelope"></i>
                <h3>email address</h3>
                <p>ordinacija@neosmile.rs</p>
                
            </div>
        </div>

        <div class="credit"> &copy; copyright @ <?php echo date('Y'); ?> by <span>Ao Web Development & Graphic Design</span> </div>
    </section>