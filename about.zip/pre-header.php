<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>info</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div class="pre-header">
        <div class="contact-info">
            <h3>Adresa</h3>
            <span><i class="fas fa-map-marker-alt"></i>Vrtlarska 7b 11 080, Zemun</span>
        </div>
        <div class="contact-info">
            <h3>Adresa</h3>
            <span><i class="fas fa-map-marker-alt"></i>Vrtlarska 7b 11 080, Zemun</span>
        </div>
        <div class="contact-info">
            <h3>Telefon</h3>
            <span><i class="fas fa-envelope"></i>+381 69 2717 777, radimo po pozivu</span>
        </div>
        <div class="contact-info">
            <h3>Radno vreme</h3>
            <span><i class="fas fa-globe"></i>Pon - Pet: 11:00 - 19:00</span>
            <span><i class="fas fa-globe"></i>Vikendom: 11:00 - 17:00</span>

        </div>
    </div>


</body>

</html>